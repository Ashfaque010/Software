import React from 'react';
import { useEntries } from '../../contexts/EntriesContext';
import { generateSerialNumber } from '../../utils/serialNumber';
import { EntryTypeSelector } from './EntryTypeSelector';
import { VehicleInfo } from './VehicleInfo';
import { WeightActions } from './WeightActions';
import type { EntryData } from '../../types';

const initialFormData: EntryData = {
  serialNumber: '',
  vehicle: '',
  driverName: '',
  driverPhone: '',
  type: null,
  name: '',
  address: '',
  material: '',
  useShipName: false,
  shipName: '',
  deduct: false,
  deductAmount: 0,
  gross: 0,
  tare: 0
};

export function EntryForm() {
  const { addEntry } = useEntries();
  const [formData, setFormData] = React.useState<EntryData>(() => ({
    ...initialFormData,
    serialNumber: generateSerialNumber()
  }));

  const handleInputChange = (field: keyof EntryData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleTypeChange = (type: 'supplier' | 'customer') => {
    setFormData(prev => ({
      ...prev,
      type,
      name: '',
      address: '',
      material: ''
    }));
  };

  const handleGetWeight = (type: 'gross' | 'tare') => {
    // Simulate weight reading
    const weight = Math.floor(Math.random() * 10000) + 5000;
    const timestamp = new Date().toLocaleString();
    
    handleInputChange(type, weight);
    handleInputChange(`${type}Time`, timestamp);

    if (formData.vehicle && formData.driverPhone) {
      const entry = {
        ...formData,
        [type]: weight,
        [`${type}Time`]: timestamp,
        id: Date.now().toString(),
        net: type === 'gross' && formData.tare ? weight - formData.tare : 
             type === 'tare' && formData.gross ? formData.gross - weight : 0,
        shipName: formData.useShipName ? formData.shipName : ''
      };
      
      addEntry(entry);
      
      // Reset form
      setFormData({
        ...initialFormData,
        serialNumber: generateSerialNumber()
      });
    } else {
      alert('Please fill in required fields (Vehicle and Driver Phone) before getting weight');
    }
  };

  return (
    <form className="p-4 space-y-6">
      <VehicleInfo
        serialNumber={formData.serialNumber}
        vehicle={formData.vehicle}
        driverName={formData.driverName}
        driverPhone={formData.driverPhone}
        onChange={handleInputChange}
      />

      <EntryTypeSelector
        selectedType={formData.type}
        formData={formData}
        onTypeChange={handleTypeChange}
        onInputChange={handleInputChange}
      />

      <WeightActions
        onGetGross={() => handleGetWeight('gross')}
        onGetTare={() => handleGetWeight('tare')}
      />
    </form>
  );
}