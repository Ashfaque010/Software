import React from 'react';
import { Button } from '../common/Button';
import { timeUtils } from '../../utils/timeUtils';

interface WeightActionsProps {
  onGetGross: (time: string) => void;
  onGetTare: (time: string) => void;
}

export function WeightActions({ onGetGross, onGetTare }: WeightActionsProps) {
  const handleGetGross = () => {
    onGetGross(timeUtils.getCurrentTime());
  };

  const handleGetTare = () => {
    onGetTare(timeUtils.getCurrentTime());
  };

  return (
    <div className="flex gap-4">
      <Button size="lg" onClick={handleGetGross}>Get Gross</Button>
      <Button size="lg" onClick={handleGetTare}>Get Tare</Button>
    </div>
  );
}