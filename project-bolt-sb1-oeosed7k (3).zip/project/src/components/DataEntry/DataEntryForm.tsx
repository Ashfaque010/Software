import React from 'react';

export function DataEntryForm() {
  return (
    <div className="p-4 space-y-6">
      <div className="grid grid-cols-4 gap-4">
        <div className="space-y-2">
          <label className="text-sm text-gray-600">Serial Number</label>
          <input type="text" className="w-full px-3 py-2 border rounded-lg" />
        </div>
        <div className="space-y-2">
          <label className="text-sm text-gray-600">Vehicle</label>
          <input type="text" className="w-full px-3 py-2 border rounded-lg" required />
        </div>
        <div className="space-y-2">
          <label className="text-sm text-gray-600">Name</label>
          <input type="text" className="w-full px-3 py-2 border rounded-lg" />
        </div>
        <div className="space-y-2">
          <label className="text-sm text-gray-600">Phone Number</label>
          <input type="tel" className="w-full px-3 py-2 border rounded-lg" required />
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center gap-4">
          <input type="radio" name="type" id="supplier" />
          <label htmlFor="supplier">Supplier</label>
          <input type="text" placeholder="name" className="px-3 py-2 border rounded-lg" />
          <input type="text" placeholder="address" className="px-3 py-2 border rounded-lg" />
          <input type="text" placeholder="material" className="px-3 py-2 border rounded-lg" />
        </div>

        <div className="flex items-center gap-4">
          <input type="radio" name="type" id="customer" />
          <label htmlFor="customer">Customer</label>
          <input type="text" placeholder="name" className="px-3 py-2 border rounded-lg" />
          <input type="text" placeholder="address" className="px-3 py-2 border rounded-lg" />
          <input type="text" placeholder="material" className="px-3 py-2 border rounded-lg" />
        </div>

        <div className="flex items-center gap-4">
          <input type="checkbox" id="deduct" />
          <label htmlFor="deduct">Deduct</label>
          <input type="text" className="px-3 py-2 border rounded-lg" />
        </div>
      </div>

      <div className="flex gap-4">
        <button className="px-6 py-2 text-white bg-green-600 rounded-lg hover:bg-green-700">
          Get Gross
        </button>
        <button className="px-6 py-2 text-white bg-green-600 rounded-lg hover:bg-green-700">
          Get Tare
        </button>
      </div>
    </div>
  );
}