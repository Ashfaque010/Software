import React from 'react';
import { Input } from '../common/Input';
import { TypeRow } from './TypeRow';
import type { EntryData } from '../../types';

interface EntryTypeSelectorProps {
  selectedType: 'supplier' | 'customer' | null;
  formData: EntryData;
  onTypeChange: (type: 'supplier' | 'customer') => void;
  onInputChange: (field: keyof EntryData, value: any) => void;
}

export function EntryTypeSelector({
  selectedType,
  formData,
  onTypeChange,
  onInputChange
}: EntryTypeSelectorProps) {
  return (
    <div className="space-y-4">
      <TypeRow
        type="supplier"
        isSelected={selectedType === 'supplier'}
        formData={formData}
        onTypeChange={onTypeChange}
        onInputChange={onInputChange}
      />
      <TypeRow
        type="customer"
        isSelected={selectedType === 'customer'}
        formData={formData}
        onTypeChange={onTypeChange}
        onInputChange={onInputChange}
      />
      
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <input 
            type="checkbox" 
            id="useShipName" 
            checked={formData.useShipName}
            onChange={(e) => onInputChange('useShipName', e.target.checked)}
            className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
          />
          <label htmlFor="useShipName" className="text-sm font-medium text-gray-700">
            Ship Name
          </label>
        </div>
        <Input 
          className="flex-1"
          disabled={!formData.useShipName}
          value={formData.useShipName ? formData.shipName : ''}
          onChange={(e) => onInputChange('shipName', e.target.value)}
          placeholder="Enter ship name"
        />
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <input 
            type="checkbox" 
            id="deduct" 
            checked={formData.deduct}
            onChange={(e) => onInputChange('deduct', e.target.checked)}
            className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
          />
          <label htmlFor="deduct" className="text-sm font-medium text-gray-700">
            Deduct
          </label>
        </div>
        <Input 
          type="number" 
          className="w-32"
          disabled={!formData.deduct}
          value={formData.deductAmount}
          onChange={(e) => onInputChange('deductAmount', parseFloat(e.target.value) || 0)}
        />
      </div>
    </div>
  );
}