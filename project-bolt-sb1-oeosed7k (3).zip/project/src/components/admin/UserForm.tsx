import React from 'react';
import { Input } from '../common/Input';
import { Button } from '../common/Button';

interface UserFormData {
  username: string;
  password: string;
  confirmPassword: string;
}

interface UserFormProps {
  onSubmit: (data: UserFormData) => void;
  type: 'add' | 'edit';
}

export function UserForm({ onSubmit, type }: UserFormProps) {
  const [formData, setFormData] = React.useState<UserFormData>({
    username: '',
    password: '',
    confirmPassword: ''
  });
  const [error, setError] = React.useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Input
        label="Username"
        value={formData.username}
        onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value }))}
        required
      />
      <Input
        label="Password"
        type="password"
        value={formData.password}
        onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
        required
      />
      <Input
        label="Confirm Password"
        type="password"
        value={formData.confirmPassword}
        onChange={(e) => setFormData(prev => ({ ...prev, confirmPassword: e.target.value }))}
        required
      />
      {error && <p className="text-red-500 text-sm">{error}</p>}
      <Button type="submit">
        {type === 'add' ? 'Add User' : 'Update User'}
      </Button>
    </form>
  );
}