import React from 'react';
import { Input } from '../common/Input';
import { Button } from '../common/Button';
import { Search } from 'lucide-react';

export function AdminQuery() {
  const [query, setQuery] = React.useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Executing query:', query);
  };

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h3 className="text-lg font-semibold mb-4">Admin Query</h3>
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input
          label="Query"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Enter your query..."
          className="font-mono"
        />
        <Button type="submit" className="flex items-center gap-2">
          <Search size={18} />
          Execute Query
        </Button>
      </form>
      <div className="mt-4 p-4 bg-gray-50 rounded-lg min-h-[200px]">
        <p className="text-gray-500">Query results will appear here...</p>
      </div>
    </div>
  );
}