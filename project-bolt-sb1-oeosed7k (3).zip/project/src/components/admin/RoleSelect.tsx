import React from 'react';
import type { User } from '../../types/auth';

interface RoleSelectProps {
  value: User['role'];
  onChange: (role: User['role']) => void;
}

export function RoleSelect({ value, onChange }: RoleSelectProps) {
  return (
    <div className="space-y-2">
      <label className="text-sm text-gray-600">Role</label>
      <select
        className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
        value={value}
        onChange={(e) => onChange(e.target.value as User['role'])}
      >
        <option value="operator">Operator</option>
        <option value="admin">Admin</option>
      </select>
    </div>
  );
}