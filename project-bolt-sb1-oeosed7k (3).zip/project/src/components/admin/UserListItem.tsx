import React from 'react';
import { Button } from '../common/Button';
import { Trash2 } from 'lucide-react';
import type { User } from '../../types/auth';

interface UserListItemProps {
  user: User;
  onDelete: (userId: string) => void;
}

export function UserListItem({ user, onDelete }: UserListItemProps) {
  return (
    <div className="py-3 flex items-center justify-between">
      <div>
        <p className="font-medium">{user.username}</p>
        <p className="text-sm text-gray-500">
          Role: <span className="capitalize">{user.role}</span>
        </p>
        <p className="text-sm text-gray-500">Last login: {user.lastLogin}</p>
      </div>
      <Button
        variant="outline"
        size="sm"
        className="text-red-600 border-red-200 hover:bg-red-50"
        onClick={() => onDelete(user.id)}
        disabled={user.id === '1'}
      >
        <Trash2 size={16} className="mr-1" />
        Delete
      </Button>
    </div>
  );
}