import React, { useState } from 'react';
import { Upload } from 'lucide-react';
import { Button } from '../common/Button';
import { logoStorage } from '../../utils/logoStorage';

export function LogoUpload() {
  const [logo, setLogo] = useState<string | null>(logoStorage.get());
  const [error, setError] = useState<string>('');

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024) { // 1MB limit
        setError('Logo file must be smaller than 1MB');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        logoStorage.save(base64String);
        setLogo(base64String);
        setError('');
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="space-y-4">
      {logo && (
        <div className="mb-4">
          <p className="text-sm text-gray-600 mb-2">Current Logo:</p>
          <img 
            src={logo} 
            alt="Company Logo" 
            className="max-w-[200px] max-h-[100px] object-contain border rounded p-2" 
          />
        </div>
      )}
      <div className="flex flex-col gap-2">
        <label className="text-sm text-gray-600">Upload New Logo (PNG/JPG, max 1MB)</label>
        <input
          type="file"
          accept="image/png,image/jpeg"
          onChange={handleLogoUpload}
          className="hidden"
          id="logo-upload"
        />
        <Button
          onClick={() => document.getElementById('logo-upload')?.click()}
          className="flex items-center gap-2"
        >
          <Upload size={18} />
          Upload Logo
        </Button>
      </div>
      {error && (
        <p className="text-red-500 text-sm">{error}</p>
      )}
    </div>
  );
}