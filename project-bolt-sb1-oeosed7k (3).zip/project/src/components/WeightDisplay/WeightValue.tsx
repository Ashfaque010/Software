import React from 'react';

interface WeightValueProps {
  label: string;
  value: number;
}

export function WeightValue({ label, value }: WeightValueProps) {
  return (
    <div>
      <span className="text-gray-600">{label}:</span>
      <span className="ml-2 font-semibold">{value.toFixed(2)}</span>
    </div>
  );
}