import React from 'react';
import { Header } from '../components/Header/Header';
import { ControlPanel } from '../components/ControlPanel/ControlPanel';
import { EntryForm } from '../components/DataEntry/EntryForm';
import { WeightDisplay } from '../components/WeightDisplay/WeightDisplay';
import { DataGrid } from '../components/DataGrid/DataGrid';
import type { EntryData } from '../types';

export function OperatorPage() {
  const handleEntrySubmit = (data: EntryData) => {
    console.log('Form submitted:', data);
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="container mx-auto">
        <ControlPanel />
        <div className="grid grid-cols-[1fr,400px]">
          <div>
            <EntryForm onSubmit={handleEntrySubmit} />
            <DataGrid />
          </div>
          <WeightDisplay />
        </div>
      </main>
    </div>
  );
}