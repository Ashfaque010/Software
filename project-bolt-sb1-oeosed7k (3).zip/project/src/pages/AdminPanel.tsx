import React, { useState } from 'react';
import { Plus, Users, Trash2, Search, Image } from 'lucide-react';
import { PageLayout } from '../components/layout/PageLayout';
import { Modal } from '../components/admin/Modal';
import { AddUserForm } from '../components/admin/AddUserForm';
import { UserList } from '../components/admin/UserList';
import { AdminQuery } from '../components/admin/AdminQuery';
import { LogoUpload } from '../components/admin/LogoUpload';

export function AdminPanel() {
  const [activeModal, setActiveModal] = useState<'add' | 'list' | 'query' | 'logo' | null>(null);

  return (
    <PageLayout title="Admin Panel">
      <div className="grid grid-cols-5 gap-6">
        <div 
          className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow cursor-pointer"
          onClick={() => setActiveModal('add')}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Plus className="w-6 h-6 text-blue-600" />
            </div>
            <h2 className="text-xl font-semibold">Add User</h2>
          </div>
          <p className="text-gray-600">Create new operator accounts</p>
        </div>

        <div 
          className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow cursor-pointer"
          onClick={() => setActiveModal('list')}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-green-100 rounded-lg">
              <Users className="w-6 h-6 text-green-600" />
            </div>
            <h2 className="text-xl font-semibold">User List</h2>
          </div>
          <p className="text-gray-600">Manage existing users</p>
        </div>

        <div 
          className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow cursor-pointer"
          onClick={() => setActiveModal('list')}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-red-100 rounded-lg">
              <Trash2 className="w-6 h-6 text-red-600" />
            </div>
            <h2 className="text-xl font-semibold">Delete User</h2>
          </div>
          <p className="text-gray-600">Remove operator accounts</p>
        </div>

        <div 
          className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow cursor-pointer"
          onClick={() => setActiveModal('query')}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Search className="w-6 h-6 text-purple-600" />
            </div>
            <h2 className="text-xl font-semibold">Admin Query</h2>
          </div>
          <p className="text-gray-600">Advanced system queries</p>
        </div>

        <div 
          className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow cursor-pointer"
          onClick={() => setActiveModal('logo')}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-orange-100 rounded-lg">
              <Image className="w-6 h-6 text-orange-600" />
            </div>
            <h2 className="text-xl font-semibold">Company Logo</h2>
          </div>
          <p className="text-gray-600">Manage print page logo</p>
        </div>
      </div>

      <Modal
        isOpen={activeModal === 'add'}
        onClose={() => setActiveModal(null)}
        title="Add New User"
      >
        <AddUserForm onClose={() => setActiveModal(null)} />
      </Modal>

      <Modal
        isOpen={activeModal === 'list'}
        onClose={() => setActiveModal(null)}
        title="User List"
      >
        <UserList />
      </Modal>

      <Modal
        isOpen={activeModal === 'query'}
        onClose={() => setActiveModal(null)}
        title="Admin Query"
      >
        <AdminQuery />
      </Modal>

      <Modal
        isOpen={activeModal === 'logo'}
        onClose={() => setActiveModal(null)}
        title="Manage Company Logo"
      >
        <LogoUpload />
      </Modal>
    </PageLayout>
  );
}