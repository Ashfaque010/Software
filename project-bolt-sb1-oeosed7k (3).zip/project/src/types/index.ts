export interface WeightData {
  gross: number;
  net: number;
  tare: number;
  realNet: number;
}

export interface EntryData {
  serialNumber: string;
  vehicle: string;
  driverName: string;
  driverPhone: string;
  type: 'supplier' | 'customer' | null;
  name: string;
  address: string;
  material: string;
  useShipName: boolean;
  shipName: string;
  deduct: boolean;
  deductAmount: number;
  grossTime?: string;
  tareTime?: string;
}

export interface GridRow {
  id: string;
  serialNumber: string;
  vehicle: string;
  type: string;
  driverName: string;
  driverPhone: string;
  material: string;
  shipName: string;
  deduct: number;
  gross: number;
  tare: number;
  net?: number;
  grossTime?: string;
  tareTime?: string;
}