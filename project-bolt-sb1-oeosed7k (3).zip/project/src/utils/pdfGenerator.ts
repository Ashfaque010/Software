import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { logoStorage } from './logoStorage';
import type { GridRow } from '../types';

export function generatePDF(entry: GridRow) {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.width;
  const margin = 20;
  const contentWidth = pageWidth - (margin * 2);
  
  // Add logo if exists
  const logo = logoStorage.get();
  if (logo) {
    doc.addImage(logo, 'JPEG', margin, 15, 40, 20, undefined, 'FAST');
  }
  
  // Header Section
  const headerY = logo ? 45 : 25;
  doc.setFontSize(22);
  doc.setTextColor(46, 125, 50);
  doc.text('Weight Measurement Report', pageWidth / 2, headerY, { align: 'center' });
  
  doc.setFontSize(14);
  doc.setTextColor(0);
  doc.text('WeightScale System', pageWidth / 2, headerY + 10, { align: 'center' });
  
  // Info Section
  const infoBoxY = headerY + 20;
  doc.setDrawColor(76, 175, 80);
  doc.setFillColor(240, 249, 240);
  doc.roundedRect(margin, infoBoxY, contentWidth, 25, 3, 3, 'FD');
  
  doc.setFontSize(11);
  doc.text(`Date: ${new Date().toLocaleString()}`, margin + 5, infoBoxY + 10);
  doc.text(`Serial Number: ${entry.serialNumber}`, margin + 5, infoBoxY + 18);
  
  // Vehicle Information Table
  autoTable(doc, {
    startY: infoBoxY + 35,
    head: [[{ content: 'Vehicle Information', colSpan: 2 }]],
    body: [
      ['Vehicle Number:', entry.vehicle],
      ['Driver Name:', entry.driverName],
      ['Driver Phone:', entry.driverPhone],
      ['Type:', entry.type],
      [`${entry.type} Name:`, entry.name],
      [`${entry.type} Address:`, entry.address],
      ['Material:', entry.material],
      ['Ship Name:', entry.shipName || '-']
    ],
    theme: 'grid',
    headStyles: {
      fillColor: [76, 175, 80],
      textColor: 255,
      fontSize: 12,
      fontStyle: 'bold'
    },
    styles: {
      fontSize: 10,
      cellPadding: 5
    },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 80 },
      1: { cellWidth: 90 }
    }
  });
  
  // Weight Information Table
  autoTable(doc, {
    startY: doc.lastAutoTable.finalY + 15,
    head: [[{ content: 'Weight Measurements', colSpan: 2 }]],
    body: [
      ['Gross Weight:', `${entry.gross.toLocaleString()} kg`],
      ['Gross Time:', entry.grossTime || '-'],
      ['Tare Weight:', `${entry.tare.toLocaleString()} kg`],
      ['Tare Time:', entry.tareTime || '-'],
      ['Net Weight:', `${(entry.gross - entry.tare).toLocaleString()} kg`],
      ['Deduct Amount:', `${entry.deduct || 0} kg`],
      ['Final Net Weight:', `${((entry.gross - entry.tare) - (entry.deduct || 0)).toLocaleString()} kg`]
    ],
    theme: 'grid',
    headStyles: {
      fillColor: [76, 175, 80],
      textColor: 255,
      fontSize: 12,
      fontStyle: 'bold'
    },
    styles: {
      fontSize: 10,
      cellPadding: 5
    },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 80 },
      1: { cellWidth: 90 }
    }
  });

  // Signatures
  const signatureY = doc.lastAutoTable.finalY + 40;
  
  doc.setFillColor(240, 249, 240);
  doc.rect(margin, signatureY - 5, 80, 30, 'F');
  doc.rect(pageWidth - margin - 80, signatureY - 5, 80, 30, 'F');
  
  doc.setDrawColor(76, 175, 80);
  doc.line(margin + 5, signatureY + 15, margin + 75, signatureY + 15);
  doc.line(pageWidth - margin - 75, signatureY + 15, pageWidth - margin - 5, signatureY + 15);
  
  doc.setFontSize(10);
  doc.text('Operator Signature', margin + 40, signatureY + 5, { align: 'center' });
  doc.text(`${entry.type} Signature`, pageWidth - margin - 40, signatureY + 5, { align: 'center' });
  
  // Footer
  const footerY = doc.internal.pageSize.height - 30;
  doc.setFillColor(240, 249, 240);
  doc.roundedRect(margin, footerY - 5, contentWidth, 25, 3, 3, 'F');
  
  doc.setFontSize(9);
  doc.setTextColor(100);
  doc.text('This is a computer generated document.', pageWidth / 2, footerY + 5, { align: 'center' });
  doc.text(`Generated on: ${new Date().toLocaleString()}`, pageWidth / 2, footerY + 12, { align: 'center' });
  
  const formattedDate = new Date().toISOString().split('T')[0];
  doc.save(`WeightReport_${entry.serialNumber}_${formattedDate}.pdf`);
}