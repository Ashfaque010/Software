// Utility for handling logo storage
export const logoStorage = {
  save: (logoData: string) => {
    localStorage.setItem('companyLogo', logoData);
  },
  
  get: (): string | null => {
    return localStorage.getItem('companyLogo');
  }
};