import React, { createContext, useContext, useState, useCallback } from 'react';
import { entriesManager, initialEntries } from '../data/entries';
import type { GridRow } from '../types';

interface EntriesContextType {
  entries: GridRow[];
  addEntry: (entry: Omit<GridRow, 'id'>) => void;
  updateEntry: (id: string, data: Partial<GridRow>) => void;
  deleteEntry: (id: string) => void;
  selectedEntry: GridRow | null;
  setSelectedEntry: (entry: GridRow | null) => void;
}

const EntriesContext = createContext<EntriesContextType | null>(null);

export function EntriesProvider({ children }: { children: React.ReactNode }) {
  const [entries, setEntries] = useState<GridRow[]>(initialEntries);
  const [selectedEntry, setSelectedEntry] = useState<GridRow | null>(null);

  const addEntry = useCallback((entry: Omit<GridRow, 'id'>) => {
    const newEntry = entriesManager.add(entry);
    setEntries(entriesManager.getAll());
    return newEntry;
  }, []);

  const updateEntry = useCallback((id: string, data: Partial<GridRow>) => {
    entriesManager.update(id, data);
    setEntries(entriesManager.getAll());
  }, []);

  const deleteEntry = useCallback((id: string) => {
    entriesManager.delete(id);
    setEntries(entriesManager.getAll());
  }, []);

  return (
    <EntriesContext.Provider value={{
      entries,
      addEntry,
      updateEntry,
      deleteEntry,
      selectedEntry,
      setSelectedEntry
    }}>
      {children}
    </EntriesContext.Provider>
  );
}

export function useEntries() {
  const context = useContext(EntriesContext);
  if (!context) {
    throw new Error('useEntries must be used within an EntriesProvider');
  }
  return context;
}