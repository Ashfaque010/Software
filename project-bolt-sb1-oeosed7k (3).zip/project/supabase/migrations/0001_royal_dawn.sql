/*
  # Create entries table for weight measurements

  1. New Tables
    - `entries`
      - `id` (uuid, primary key)
      - `serial_number` (text)
      - `vehicle` (text)
      - `driver_name` (text)
      - `driver_phone` (text)
      - `type` (text) - 'supplier' or 'customer'
      - `name` (text)
      - `address` (text)
      - `material` (text)
      - `use_ship_name` (boolean)
      - `ship_name` (text)
      - `deduct` (boolean)
      - `deduct_amount` (numeric)
      - `gross` (numeric)
      - `tare` (numeric)
      - `net` (numeric)
      - `gross_time` (timestamptz)
      - `tare_time` (timestamptz)
      - `created_at` (timestamptz)
      - `user_id` (uuid, foreign key)

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

CREATE TABLE IF NOT EXISTS entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  serial_number text NOT NULL,
  vehicle text NOT NULL,
  driver_name text,
  driver_phone text NOT NULL,
  type text NOT NULL CHECK (type IN ('supplier', 'customer')),
  name text,
  address text,
  material text,
  use_ship_name boolean DEFAULT false,
  ship_name text,
  deduct boolean DEFAULT false,
  deduct_amount numeric DEFAULT 0,
  gross numeric DEFAULT 0,
  tare numeric DEFAULT 0,
  net numeric DEFAULT 0,
  gross_time timestamptz,
  tare_time timestamptz,
  created_at timestamptz DEFAULT now(),
  user_id uuid REFERENCES auth.users(id)
);

ALTER TABLE entries ENABLE ROW LEVEL SECURITY;

-- Allow users to read all entries
CREATE POLICY "Users can read all entries"
  ON entries
  FOR SELECT
  TO authenticated
  USING (true);

-- Users can only insert their own entries
CREATE POLICY "Users can insert their own entries"
  ON entries
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Users can only update their own entries
CREATE POLICY "Users can update their own entries"
  ON entries
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);