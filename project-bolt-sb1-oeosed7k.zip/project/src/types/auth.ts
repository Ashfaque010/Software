export interface User {
  id: string;
  username: string;
  role: 'admin' | 'operator';
  lastLogin?: string;
}

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface NewUser {
  username: string;
  password: string;
  role: 'admin' | 'operator';
}