import React from 'react';
import { Button } from '../common/Button';
import { Check } from 'lucide-react';
import type { GridRow as GridRowType } from '../../types';

interface GridRowProps {
  row: GridRowType;
  isSelected: boolean;
  onSelect: () => void;
}

export function GridRow({ row, isSelected, onSelect }: GridRowProps) {
  return (
    <div className={`grid grid-cols-9 gap-2 items-center py-2 px-3 rounded-lg transition-colors ${
      isSelected ? 'bg-green-50 border border-green-200' : 'hover:bg-gray-50'
    }`}>
      <Button
        size="sm"
        variant={isSelected ? 'primary' : 'outline'}
        className={`w-20 ${isSelected ? 'bg-green-600' : 'border-green-200 text-green-600'}`}
        onClick={onSelect}
      >
        {isSelected ? (
          <span className="flex items-center gap-1">
            <Check size={16} />
            Selected
          </span>
        ) : (
          'Select'
        )}
      </Button>
      <span className="text-sm">{row.serialNumber}</span>
      <span className="text-sm">{row.vehicle}</span>
      <span className="text-sm font-medium">
        <span className={`px-2 py-1 rounded-full text-xs ${
          row.type === 'Supplier' 
            ? 'bg-blue-100 text-blue-700'
            : 'bg-green-100 text-green-700'
        }`}>
          {row.type}
        </span>
      </span>
      <span className="text-sm">{row.driverName}</span>
      <span className="text-sm">{row.material}</span>
      <span className="text-sm">{row.deduct}</span>
      <span className="text-sm">{row.gross.toLocaleString()}</span>
      <span className="text-sm">{row.tare.toLocaleString()}</span>
    </div>
  );
}