import React from 'react';
import { Button } from '../common/Button';

interface GridHeaderProps {
  onSort: (column: string) => void;
}

export function GridHeader({ onSort }: GridHeaderProps) {
  const headers = [
    'Action',
    'Serial Number',
    'Vehicle',
    'Type',
    'Name',
    'Material',
    'Deduct',
    'Gross',
    'Tare'
  ];

  return (
    <div className="grid grid-cols-9 gap-2 mb-2">
      {headers.map((header) => (
        <Button
          key={header}
          variant="outline"
          size="sm"
          onClick={() => onSort(header)}
          className="text-sm text-gray-600"
        >
          {header}
        </Button>
      ))}
    </div>
  );
}