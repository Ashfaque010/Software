import React from 'react';
import { GridHeader } from './GridHeader';
import { GridRow } from './GridRow';
import { useEntries } from '../../contexts/EntriesContext';

export function DataGrid() {
  const { entries, selectedEntry, setSelectedEntry } = useEntries();
  const [sortColumn, setSortColumn] = React.useState<string | null>(null);

  const handleSort = (column: string) => {
    setSortColumn(column);
    // Implement sorting logic here
  };

  const handleSelect = (id: string) => {
    const entry = entries.find(e => e.id === id);
    setSelectedEntry(entry === selectedEntry ? null : entry);
  };

  return (
    <div className="p-4">
      <GridHeader onSort={handleSort} />
      <div className="space-y-2">
        {entries.map((row) => (
          <GridRow 
            key={row.id}
            row={row}
            isSelected={row.id === selectedEntry?.id}
            onSelect={() => handleSelect(row.id)}
          />
        ))}
      </div>
    </div>
  );
}