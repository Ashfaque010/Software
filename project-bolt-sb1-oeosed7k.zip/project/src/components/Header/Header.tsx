import React from 'react';
import { LogOut } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

export function Header() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header className="flex items-center justify-between p-4 border-b bg-white">
      <div className="flex items-center gap-4">
        <button className="px-3 py-1 text-green-600 border border-green-600 rounded-full text-sm hover:bg-green-50">
          Contributors
        </button>
        <span className="text-gray-600">
          Logged in as <span className="font-medium capitalize">{user?.role}</span>
        </span>
      </div>
      <button 
        onClick={handleLogout}
        className="flex items-center gap-2 px-4 py-2 text-green-600 hover:bg-green-50 rounded-lg"
      >
        <span>Log out</span>
        <LogOut size={18} />
      </button>
    </header>
  );
}