import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../common/Button';
import { Trash2 } from 'lucide-react';
import { UserListItem } from './UserListItem';
import type { User } from '../../types/auth';

export function UserList() {
  const { users, deleteUser } = useAuth();
  const [error, setError] = useState<string>('');

  const handleDelete = (userId: string) => {
    try {
      deleteUser(userId);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete user');
    }
  };

  return (
    <div className="space-y-4">
      {error && <p className="text-red-500 text-sm">{error}</p>}
      <div className="divide-y">
        {users.map(user => (
          <UserListItem 
            key={user.id}
            user={user}
            onDelete={handleDelete}
          />
        ))}
      </div>
    </div>
  );
}