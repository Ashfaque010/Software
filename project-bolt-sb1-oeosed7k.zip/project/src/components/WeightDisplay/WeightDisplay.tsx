import React from 'react';
import { Printer } from 'lucide-react';
import { Button } from '../common/Button';
import { WeightValue } from './WeightValue';
import { useEntries } from '../../contexts/EntriesContext';
import { generatePDF } from '../../utils/pdfGenerator';
import type { WeightData } from '../../types';

const initialWeightData: WeightData = {
  gross: 0,
  net: 0,
  tare: 0,
  realNet: 0
};

export function WeightDisplay() {
  const { selectedEntry } = useEntries();
  const [weights] = React.useState<WeightData>(initialWeightData);

  const handlePrint = () => {
    if (selectedEntry) {
      generatePDF(selectedEntry);
    } else {
      alert('Please select an entry to print');
    }
  };

  return (
    <div className="p-4 border-l">
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <WeightValue label="Gross" value={weights.gross} />
          <WeightValue label="Net" value={weights.net} />
          <WeightValue label="Tare" value={weights.tare} />
          <WeightValue label="Real Net" value={weights.realNet} />
        </div>

        <div className="flex gap-2">
          <Button 
            variant="outline" 
            className={`flex items-center gap-2 ${!selectedEntry ? 'opacity-50 cursor-not-allowed' : ''}`}
            onClick={handlePrint}
            disabled={!selectedEntry}
          >
            <Printer size={18} />
            <span>Print Selected</span>
          </Button>
          <Button variant="outline">Date Just Show</Button>
          <Button variant="outline">List</Button>
          <Button variant="outline">Not Finished</Button>
        </div>
      </div>
    </div>
  );
}