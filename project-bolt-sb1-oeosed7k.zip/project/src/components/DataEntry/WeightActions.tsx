import React from 'react';
import { Button } from '../common/Button';

export function WeightActions() {
  return (
    <div className="flex gap-4">
      <Button size="lg">Get Gross</Button>
      <Button size="lg">Get Tare</Button>
    </div>
  );
}