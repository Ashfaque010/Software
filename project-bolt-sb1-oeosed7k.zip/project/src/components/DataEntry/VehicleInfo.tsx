import React from 'react';
import { Input } from '../common/Input';
import type { EntryData } from '../../types';

interface VehicleInfoProps {
  serialNumber: string;
  vehicle: string;
  driverName: string;
  driverPhone: string;
  onChange: (field: keyof EntryData, value: string) => void;
}

export function VehicleInfo({
  serialNumber,
  vehicle,
  driverName,
  driverPhone,
  onChange
}: VehicleInfoProps) {
  return (
    <div className="grid grid-cols-4 gap-4">
      <Input 
        label="Serial Number" 
        type="text" 
        value={serialNumber} 
        disabled 
        className="bg-gray-50"
      />
      <Input 
        label="Vehicle Number" 
        type="text" 
        required
        value={vehicle}
        onChange={(e) => onChange('vehicle', e.target.value)}
      />
      <Input 
        label="Driver Name" 
        type="text"
        value={driverName}
        onChange={(e) => onChange('driverName', e.target.value)}
      />
      <Input 
        label="Driver Phone" 
        type="tel" 
        required
        value={driverPhone}
        onChange={(e) => onChange('driverPhone', e.target.value)}
      />
    </div>
  );
}