import React, { createContext, useContext, useState } from 'react';
import { initialUsers } from '../data/users';
import { validateCredentials, getUserRole, formatLastLogin } from '../utils/auth';
import type { User, LoginCredentials, NewUser } from '../types/auth';

interface AuthContextType {
  user: User | null;
  users: User[];
  login: (credentials: LoginCredentials) => boolean;
  logout: () => void;
  addUser: (newUser: NewUser) => void;
  deleteUser: (userId: string) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(initialUsers);

  const login = (credentials: LoginCredentials) => {
    if (validateCredentials(credentials)) {
      const foundUser = users.find(u => u.username === credentials.username);
      if (foundUser) {
        setUser({
          ...foundUser,
          lastLogin: formatLastLogin(new Date())
        });
        return true;
      }
    }
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  const addUser = (newUser: NewUser) => {
    const userExists = users.some(u => u.username === newUser.username);
    if (userExists) {
      throw new Error('Username already exists');
    }

    const user: User = {
      id: Date.now().toString(),
      username: newUser.username,
      role: newUser.role,
      lastLogin: '-'
    };

    setUsers(prev => [...prev, user]);
  };

  const deleteUser = (userId: string) => {
    if (userId === '1') {
      throw new Error('Cannot delete main admin account');
    }
    setUsers(prev => prev.filter(user => user.id !== userId));
  };

  return (
    <AuthContext.Provider value={{ user, users, login, logout, addUser, deleteUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}