let currentNumber = 1;

export function generateSerialNumber(): string {
  const serialNumber = `WS${currentNumber.toString().padStart(3, '0')}`;
  currentNumber++;
  return serialNumber;
}

export function resetSerialNumber(): void {
  currentNumber = 1;
}

export function getCurrentNumber(): number {
  return currentNumber;
}