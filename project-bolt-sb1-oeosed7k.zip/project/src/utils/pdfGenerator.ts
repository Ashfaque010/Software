import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { GridRow } from '../types';

export function generatePDF(entry: GridRow) {
  const doc = new jsPDF();
  const pageWidth = doc.internal.pageSize.width;
  const margin = 20;
  const contentWidth = pageWidth - (margin * 2);
  
  // Header Section
  doc.setFontSize(22);
  doc.setTextColor(46, 125, 50); // Green color
  doc.text('Weight Measurement Report', pageWidth / 2, 25, { align: 'center' });
  
  doc.setFontSize(14);
  doc.setTextColor(0);
  doc.text('WeightScale System', pageWidth / 2, 35, { align: 'center' });
  
  // Info Section
  const date = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
  
  // Create info box
  doc.setDrawColor(76, 175, 80);
  doc.setFillColor(240, 249, 240);
  doc.roundedRect(margin, 45, contentWidth, 25, 3, 3, 'FD');
  
  doc.setFontSize(11);
  doc.text(`Date: ${date}`, margin + 5, 55);
  doc.text(`Serial Number: ${entry.serialNumber}`, margin + 5, 63);
  
  // Vehicle Information Table
  autoTable(doc, {
    startY: 80,
    head: [[{ content: 'Vehicle Information', colSpan: 2 }]],
    body: [
      ['Vehicle Number:', entry.vehicle],
      ['Driver Name:', entry.driverName],
      ['Driver Phone:', entry.driverPhone],
      ['Type:', entry.type],
      ['Material:', entry.material]
    ],
    theme: 'grid',
    headStyles: {
      fillColor: [76, 175, 80],
      textColor: 255,
      fontSize: 12,
      fontStyle: 'bold',
      halign: 'left',
      cellPadding: { top: 5, bottom: 5, left: 8, right: 8 }
    },
    bodyStyles: {
      fontSize: 11,
      cellPadding: { top: 4, bottom: 4, left: 8, right: 8 }
    },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 80 },
      1: { cellWidth: 90 }
    },
    margin: { left: margin, right: margin }
  });
  
  // Weight Information Table
  autoTable(doc, {
    startY: doc.lastAutoTable.finalY + 15,
    head: [[{ content: 'Weight Measurements', colSpan: 2 }]],
    body: [
      ['Gross Weight:', `${entry.gross.toLocaleString()} kg`],
      ['Tare Weight:', `${entry.tare.toLocaleString()} kg`],
      ['Net Weight:', `${(entry.gross - entry.tare).toLocaleString()} kg`],
      ['Deduction:', `${entry.deduct} kg`],
      ['Final Net Weight:', `${((entry.gross - entry.tare) - entry.deduct).toLocaleString()} kg`]
    ],
    theme: 'grid',
    headStyles: {
      fillColor: [76, 175, 80],
      textColor: 255,
      fontSize: 12,
      fontStyle: 'bold',
      halign: 'left',
      cellPadding: { top: 5, bottom: 5, left: 8, right: 8 }
    },
    bodyStyles: {
      fontSize: 11,
      cellPadding: { top: 4, bottom: 4, left: 8, right: 8 }
    },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 80 },
      1: { cellWidth: 90 }
    },
    margin: { left: margin, right: margin }
  });

  // Signature Section
  const signatureY = doc.lastAutoTable.finalY + 40;
  
  // Signature boxes with light green background
  doc.setFillColor(240, 249, 240);
  doc.rect(margin, signatureY - 5, 80, 30, 'F');
  doc.rect(pageWidth - margin - 80, signatureY - 5, 80, 30, 'F');
  
  // Signature lines
  doc.setDrawColor(76, 175, 80);
  doc.line(margin + 5, signatureY + 15, margin + 75, signatureY + 15);
  doc.line(pageWidth - margin - 75, signatureY + 15, pageWidth - margin - 5, signatureY + 15);
  
  doc.setFontSize(10);
  doc.text('Operator Signature', margin + 40, signatureY + 5, { align: 'center' });
  doc.text('Customer Signature', pageWidth - margin - 40, signatureY + 5, { align: 'center' });
  
  // Footer
  const footerY = doc.internal.pageSize.height - 30;
  
  // Footer box
  doc.setFillColor(240, 249, 240);
  doc.roundedRect(margin, footerY - 5, contentWidth, 25, 3, 3, 'F');
  
  doc.setFontSize(9);
  doc.setTextColor(100);
  doc.text('This is a computer generated document.', pageWidth / 2, footerY + 5, { align: 'center' });
  doc.text(`Generated on: ${date}`, pageWidth / 2, footerY + 12, { align: 'center' });
  
  // Save with formatted name
  const formattedDate = new Date().toISOString().split('T')[0];
  doc.save(`WeightReport_${entry.serialNumber}_${formattedDate}.pdf`);
}