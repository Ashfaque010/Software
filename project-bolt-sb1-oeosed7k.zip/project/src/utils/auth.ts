import { defaultCredentials } from '../data/credentials';
import type { LoginCredentials } from '../types/auth';

export function validateCredentials({ username, password }: LoginCredentials): boolean {
  const credentials = defaultCredentials[username];
  return credentials?.password === password;
}

export function getUserRole(username: string): 'admin' | 'operator' | null {
  return defaultCredentials[username]?.role || null;
}

export function formatLastLogin(date: Date): string {
  return date.toLocaleString('en-US', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  });
}