import type { GridRow } from '../types';

// Initial demo data
export const initialEntries: GridRow[] = [
  {
    id: '1',
    serialNumber: 'WS001',
    vehicle: 'TRK-123',
    type: 'Supplier',
    driverName: 'John Smith',
    driverPhone: '555-0123',
    material: 'Sand',
    deduct: 0,
    gross: 15000,
    tare: 5000,
    net: 10000
  }
];

// In-memory storage for new entries
let entries: GridRow[] = [...initialEntries];

export const entriesManager = {
  getAll: () => entries,
  
  add: (entry: Omit<GridRow, 'id'>) => {
    const newEntry: GridRow = {
      ...entry,
      id: Date.now().toString()
    };
    entries = [...entries, newEntry];
    return newEntry;
  },
  
  update: (id: string, data: Partial<GridRow>) => {
    entries = entries.map(entry => 
      entry.id === id ? { ...entry, ...data } : entry
    );
    return entries.find(entry => entry.id === id);
  },
  
  delete: (id: string) => {
    entries = entries.filter(entry => entry.id !== id);
  },
  
  getById: (id: string) => {
    return entries.find(entry => entry.id === id);
  }
};