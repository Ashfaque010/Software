interface Credentials {
  username: string;
  password: string;
  role: 'admin' | 'operator';
}

export const defaultCredentials: Record<string, Credentials> = {
  admin: {
    username: 'admin',
    password: 'admin',
    role: 'admin'
  },
  user: {
    username: 'user',
    password: 'user',
    role: 'operator'
  }
};