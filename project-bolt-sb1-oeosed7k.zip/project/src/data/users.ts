import type { User } from '../types/auth';

// Initial users data
export const initialUsers: User[] = [
  { 
    id: '1',
    username: 'admin',
    role: 'admin',
    lastLogin: '2024-03-15 10:30'
  },
  { 
    id: '2',
    username: 'user',
    role: 'operator',
    lastLogin: '2024-03-14 15:45'
  }
];